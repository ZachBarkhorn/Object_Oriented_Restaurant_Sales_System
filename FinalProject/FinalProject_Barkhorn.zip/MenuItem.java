public class MenuItem {
    protected String name;
    protected double price;
    protected int item_number;

    public MenuItem(String arg_name, double arg_price, int arg_min){
        name = arg_name;
        price = arg_price;
        item_number = arg_min;
    }

}
