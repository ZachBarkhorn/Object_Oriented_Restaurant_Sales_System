public interface TableObserver {
    void update(Table table);
}
